/**
 * Created by ericjohnson on 3/26/16.
 */

exports.handler = function(event, context){
  context.succeed('All Good');
};